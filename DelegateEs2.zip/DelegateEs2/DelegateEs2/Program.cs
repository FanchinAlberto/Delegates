﻿using System;

namespace DelegateEs2
{
    class Program
    {

        public delegate int FunctionDel(int n);
        static void Main(string[] args)
        {
            FunctionDel del = new FunctionDel(calculateSquare);
            Console.WriteLine("Inserisci un valore");
            int n = Convert.ToInt32(Console.ReadLine());
            n = del(n);
            Console.WriteLine("Quadrato: {0}", n);
            del += new FunctionDel(calculateCube);
            n = del(n);
            Console.WriteLine("Cubo del quadrato: {0}", n);
        }

        static public int calculateSquare(int n)
        {
            return n*n;
        }

        static public int calculateCube(int n)
        {
            return n * n* n;
        }
    }
}
